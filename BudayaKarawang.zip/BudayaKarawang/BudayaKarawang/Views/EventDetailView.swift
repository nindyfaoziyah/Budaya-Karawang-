//
//  EventDetailView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 12/03/26.
//

import SwiftUI

struct EventDetailView: View {

    let event: EventBudaya
    @State private var showSections: [String: Bool] = [:]

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {

                // FOTO EVENT
                Image("eventkrw")
                    .resizable()
                    .scaledToFill()
                    .frame(height: 220)
                    .frame(maxWidth: .infinity)
                    .clipped()
                    .cornerRadius(15)
                    .shadow(radius: 5)
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(Color.orange.opacity(0.3), lineWidth: 2)
                    )
                    .padding(.horizontal)
                    .transition(.scale.combined(with: .opacity))
                    .animation(.easeOut(duration: 0.5), value: showSections["gambar"])

                // NAMA EVENT
                Text(event.nama)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.orange)
                    .padding(.horizontal)
                    .transition(.move(edge: .leading).combined(with: .opacity))
                    .animation(.easeOut(duration: 0.5).delay(0.1), value: showSections["nama"])

                // TANGGAL & LOKASI
                HStack(spacing: 15) {
                    Label(event.tanggal, systemImage: "calendar")
                        .padding(8)
                        .background(Color.orange.opacity(0.2))
                        .cornerRadius(10)
                    Label(event.lokasi, systemImage: "mappin.and.ellipse")
                        .padding(8)
                        .background(Color.orange.opacity(0.2))
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                .transition(.move(edge: .leading).combined(with: .opacity))
                .animation(.easeOut(duration: 0.5).delay(0.2), value: showSections["info"])

                // DESKRIPSI (Card)
                VStack(alignment: .leading, spacing: 10) {
                    Text("Deskripsi Event")
                        .font(.headline)
                        .foregroundColor(.orange)
                    Text(event.deskripsi)
                        .font(.body)
                        .foregroundColor(.black)
                        .lineSpacing(4)
                }
                .padding()
                .background(Color.white)
                .cornerRadius(15)
                .shadow(color: Color.black.opacity(0.08), radius: 6)
                .padding(.horizontal)
                .transition(.move(edge: .trailing).combined(with: .opacity))
                .animation(.easeOut(duration: 0.5).delay(0.3), value: showSections["deskripsi"])

                Spacer()
            }
            .padding(.vertical)
        }
        .navigationTitle("Detail Event")
        .navigationBarTitleDisplayMode(.inline)
        .background(Color.orange.opacity(0.05))
        .onAppear {
            // Trigger animasi saat muncul
            showSections = [
                "gambar": true,
                "nama": true,
                "info": true,
                "deskripsi": true
            ]
        }
    }
}

