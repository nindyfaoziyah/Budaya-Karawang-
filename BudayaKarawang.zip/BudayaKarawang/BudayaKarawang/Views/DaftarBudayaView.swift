//
//  DaftarBudayaView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 12/03/26.
//

import SwiftUI

struct DaftarBudayaView: View {

    @State private var searchText = ""
    @State private var selectedKategori = "Semua"
    @State private var showCards: [UUID: Bool] = [:] // untuk animasi per card

    let kategoriList = [
        "Semua",
        "Seni Tari",
        "Musik Tradisional",
        "Makanan Khas",
        "Tradisi / Adat",
        "Tempat Bersejarah"
    ]

    var filteredBudaya: [Budaya] {
        budayaData.filter { budaya in
            let cocokSearch = searchText.isEmpty ||
            budaya.nama.lowercased().contains(searchText.lowercased())

            let cocokKategori = selectedKategori == "Semua" ||
            budaya.kategori == selectedKategori

            return cocokSearch && cocokKategori
        }
    }

    var body: some View {
        NavigationStack { // <--- HARUS ADA
            ScrollView {

                VStack(spacing: 20) {

                    // SEARCH BAR
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("Cari budaya...", text: $searchText)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    .padding(.horizontal)

                    // FILTER KATEGORI
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(kategoriList, id:\.self) { kategori in
                                Button {
                                    selectedKategori = kategori
                                } label: {
                                    Text(kategori)
                                        .font(.subheadline)
                                        .padding(.vertical, 8)
                                        .padding(.horizontal, 14)
                                        .background(
                                            selectedKategori == kategori ?
                                            Color.orange : Color.orange.opacity(0.2)
                                        )
                                        .foregroundColor(
                                            selectedKategori == kategori ?
                                            .white : .orange
                                        )
                                        .cornerRadius(20)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }

                    // LIST BUDAYA (CARD STYLE + ANIMASI)
                    LazyVStack(spacing: 15) {

                        ForEach(filteredBudaya) { budaya in

                            NavigationLink(destination: DetailBudayaView(budaya: budaya)) {

                                HStack(spacing: 15) {

                                    // ICON / GAMBAR
                                    Image(systemName: "theatermasks.fill")
                                        .font(.system(size: 28))
                                        .foregroundColor(.white)
                                        .frame(width: 55, height: 55)
                                        .background(Color.orange)
                                        .cornerRadius(12)
                                        .scaleEffect(showCards[budaya.id] == true ? 1 : 0.8)
                                        .opacity(showCards[budaya.id] == true ? 1 : 0)

                                    // TEXT
                                    VStack(alignment: .leading, spacing: 5) {

                                        Text(budaya.nama)
                                            .font(.headline)
                                            .foregroundColor(.black)

                                        Text(budaya.deskripsi)
                                            .font(.caption)
                                            .lineLimit(2)
                                            .foregroundColor(.gray)
                                    }

                                    Spacer()

                                    Image(systemName: "chevron.right")
                                        .foregroundColor(.gray)
                                        .opacity(showCards[budaya.id] == true ? 1 : 0)
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(15)
                                .shadow(color: Color.black.opacity(0.08), radius: 6)
                                .contentShape(Rectangle()) // seluruh card bisa ditekan
                                .offset(y: showCards[budaya.id] == true ? 0 : 20)
                                .animation(.easeOut(duration: 0.4).delay(Double(filteredBudaya.firstIndex(where: { $0.id == budaya.id }) ?? 0) * 0.05), value: showCards[budaya.id])
                            }
                            .buttonStyle(.plain)
                            .onAppear {
                                withAnimation {
                                    showCards[budaya.id] = true
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .background(Color.orange.opacity(0.05))
            .navigationTitle("Daftar Budaya")
        }
    }
}
