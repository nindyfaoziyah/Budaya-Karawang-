//
//  HomeView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 12/03/26.
//

import SwiftUI

struct HomeView: View {
    @State private var searchText = ""
    @State private var animateBanner = false

    var filteredBudaya: [Budaya] {
        if searchText.isEmpty {
            return budayaData
        } else {
            return budayaData.filter {
                $0.nama.lowercased().contains(searchText.lowercased())
            }
        }
    }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {

                    // Banner
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.orange.opacity(0.7))
                            .frame(height: 160)
                            .shadow(color: Color.orange.opacity(0.4), radius: 8, x: 0, y: 4)

                        Text("Budaya Karawang")
                            .font(.largeTitle)
                            .fontWeight(.heavy)
                            .foregroundColor(.white)
                            .scaleEffect(animateBanner ? 1 : 0.8)
                            .opacity(animateBanner ? 1 : 0)
                            .animation(.easeInOut(duration: 1), value: animateBanner)
                    }
                    .onAppear {
                        animateBanner = true
                    }
                    .padding(.horizontal)

                    // Tombol Menu Game Susun Kata Budaya
                    NavigationLink(destination: SusunKataGameView()) {
                        Text("Susun Kata Budaya")
                            .fontWeight(.bold)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)

                    // Search
                    TextField("Cari Budaya...", text: $searchText)
                        .padding(12)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal)

                    // Kategori
                    Text("Kategori Budaya")
                        .font(.headline)
                        .padding(.horizontal)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 14) {
                            kategoriItem(nama: "Tarian")
                            kategoriItem(nama: "Seni")
                            kategoriItem(nama: "Kuliner")
                            kategoriItem(nama: "Wisata")
                        }
                        .padding(.horizontal)
                    }

                    // Rekomendasi
                    Text("Rekomendasi Budaya")
                        .font(.headline)
                        .padding([.top, .horizontal])

                    VStack(spacing: 16) {
                        ForEach(filteredBudaya) { budaya in

                            NavigationLink(destination: DetailBudayaView(budaya: budaya)) {

                                HStack(spacing: 16) {

                                    Circle()
                                        .fill(Color.orange)
                                        .frame(width: 55, height: 55)
                                        .overlay(
                                            Text(String(budaya.nama.prefix(1)))
                                                .font(.title2)
                                                .fontWeight(.bold)
                                                .foregroundColor(.white)
                                        )

                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(budaya.nama)
                                            .font(.headline)
                                        Text(budaya.kategori)
                                            .font(.subheadline)
                                            .foregroundColor(.secondary)
                                    }

                                    Spacer()
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(14)
                                .shadow(color: Color.black.opacity(0.08), radius: 6, x: 0, y: 3)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
                .background(Color.orange.opacity(0.05))
            }
            .navigationTitle("Beranda")
        }
    }

    // Komponen kategori
    func kategoriItem(nama: String) -> some View {
        Text(nama)
            .fontWeight(.medium)
            .padding(.vertical, 8)
            .padding(.horizontal, 18)
            .background(Color.orange.opacity(0.2))
            .cornerRadius(20)
            .foregroundColor(Color.orange)
            .shadow(color: Color.orange.opacity(0.1), radius: 2, x: 0, y: 1)
    }
}
