//
//  GameBudayaView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 11/03/26.
//
import SwiftUI

import SwiftUI

struct GameMenuView: View {
    
    var body: some View {
        NavigationView {
            ScrollView {
                
                VStack(spacing: 25) {
                    
                    // Header
                    VStack(spacing: 10) {
                        Image(systemName: "gamecontroller.fill")
                            .font(.system(size: 60))
                            .foregroundColor(.orange)
                        
                        Text("Game Budaya")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        
                        Text("Mainkan game seru untuk mengenal budaya Karawang")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 20)
                    
                    
                    // Card Game Susun Kata
                    NavigationLink(destination: SusunKataGameView()) {
                        
                        HStack(spacing: 16) {
                            
                            Image(systemName: "textformat")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                                .frame(width: 55, height: 55)
                                .background(Color.orange)
                                .cornerRadius(12)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                
                                Text("Susun Kata Budaya")
                                    .font(.headline)
                                    .foregroundColor(.black)
                                
                                Text("Susun huruf menjadi nama budaya")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(color: Color.black.opacity(0.08), radius: 6, x: 0, y: 3)
                    }
                    
                    
                    Spacer()
                }
                .padding()
            }
            .background(Color.orange.opacity(0.05))
            .navigationTitle("Game")
        }
    }
}
