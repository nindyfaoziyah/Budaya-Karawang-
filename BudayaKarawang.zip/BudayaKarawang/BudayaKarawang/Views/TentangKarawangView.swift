//
//  TentangKarawangView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 12/03/26.
//

import SwiftUI
import MapKit

struct TentangKarawangView: View {

    @State private var position = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: -6.3227, longitude: 107.3376),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
    )

    @State private var showHeader = false
    @State private var showCard1 = false
    @State private var showCard2 = false
    @State private var showMap = false
    @State private var showInfo = false

    var body: some View {

        ScrollView {

            VStack(spacing: 25) {

                // HEADER
                VStack(spacing: 10) {

                    Image(systemName: "building.columns.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.orange)
                        .scaleEffect(showHeader ? 1 : 0.6)

                    Text("Karawang")
                        .font(.largeTitle)
                        .fontWeight(.bold)

                    Text("Kota dengan kekayaan budaya dan sejarah di Jawa Barat")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)

                }
                .opacity(showHeader ? 1 : 0)
                .offset(y: showHeader ? 0 : -20)
                .animation(.easeOut(duration: 0.6), value: showHeader)

                // PROFIL BUDAYA
                infoCard(
                    icon: "theatermasks.fill",
                    title: "Profil Budaya Karawang",
                    text: "Karawang merupakan daerah di Jawa Barat yang memiliki kekayaan budaya seperti tari tradisional, musik daerah, kuliner khas, serta berbagai tradisi masyarakat."
                )
                .opacity(showCard1 ? 1 : 0)
                .offset(y: showCard1 ? 0 : 30)
                .animation(.easeOut(duration: 0.6), value: showCard1)

                // SEJARAH
                infoCard(
                    icon: "clock.arrow.circlepath",
                    title: "Sejarah Singkat",
                    text: "Karawang dikenal sebagai daerah yang memiliki sejarah panjang sejak masa kerajaan hingga masa perjuangan kemerdekaan Indonesia. Karawang adalah kota padi yang berubah menjadi kota industri."
                )
                .opacity(showCard2 ? 1 : 0)
                .offset(y: showCard2 ? 0 : 30)
                .animation(.easeOut(duration: 0.6), value: showCard2)

                // MAP
                VStack(alignment: .leading, spacing: 10) {

                    Label("Peta Lokasi Karawang", systemImage: "map.fill")
                        .font(.headline)

                    Map(position: $position) {
                        Marker(
                            "Karawang",
                            coordinate: CLLocationCoordinate2D(
                                latitude: -6.3227,
                                longitude: 107.3376
                            )
                        )
                    }
                    .frame(height: 220)
                    .cornerRadius(15)

                }
                .padding()
                .background(Color.white)
                .cornerRadius(15)
                .shadow(color: Color.black.opacity(0.08), radius: 6)
                .scaleEffect(showMap ? 1 : 0.9)
                .opacity(showMap ? 1 : 0)
                .animation(.easeOut(duration: 0.6), value: showMap)

                // INFO WISATA
                VStack(alignment: .leading, spacing: 8) {

                    Label("Informasi Wisata", systemImage: "location.fill")
                        .font(.headline)

                    Text("Alamat:")
                        .fontWeight(.semibold)

                    Text("Jl. Pangkal Perjuangan KM 1, Tanjungpura, Karawang Barat")

                    Divider()

                    Text("Kontak Pariwisata:")
                        .fontWeight(.semibold)

                    Text("Dinas Pariwisata Karawang")

                }
                .padding()
                .background(Color.white)
                .cornerRadius(15)
                .shadow(color: Color.black.opacity(0.08), radius: 6)
                .opacity(showInfo ? 1 : 0)
                .offset(y: showInfo ? 0 : 30)
                .animation(.easeOut(duration: 0.6), value: showInfo)

            }
            .padding()
        }
        .background(Color.orange.opacity(0.05))
        .navigationTitle("Tentang Karawang")
        .onAppear {

            showHeader = true

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                showCard1 = true
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                showCard2 = true
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                showMap = true
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                showInfo = true
            }
        }
    }


    // CARD COMPONENT
    func infoCard(icon: String, title: String, text: String) -> some View {

        VStack(alignment: .leading, spacing: 10) {

            Label(title, systemImage: icon)
                .font(.headline)

            Text(text)
                .font(.body)

        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.08), radius: 6)
    }
}
