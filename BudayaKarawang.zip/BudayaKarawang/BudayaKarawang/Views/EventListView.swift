//
//  EventListView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 12/03/26.
//

import SwiftUI

struct EventListView: View {
    
    @State private var showCards: [UUID: Bool] = [:] // untuk animasi per card
    
    var body: some View {
        
        NavigationStack {
            
            ScrollView {
                
                VStack(spacing: 16) {
                    
                    ForEach(eventData) { event in
                        
                        NavigationLink(destination: EventDetailView(event: event)) {
                            
                            HStack(spacing: 15) {
                                
                                // Icon Event dengan animasi scale saat muncul
                                Image(systemName: "calendar.circle.fill")
                                    .font(.system(size: 40))
                                    .foregroundColor(.orange)
                                    .scaleEffect(showCards[event.id] == true ? 1 : 0.8)
                                    .opacity(showCards[event.id] == true ? 1 : 0)
                                
                                // Informasi Event
                                VStack(alignment: .leading, spacing: 4) {
                                    
                                    Text(event.nama)
                                        .font(.headline)
                                        .foregroundColor(.black)
                                    
                                    HStack {
                                        Image(systemName: "clock")
                                            .font(.caption)
                                            .foregroundColor(.gray)
                                        
                                        Text(event.tanggal)
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                }
                                
                                Spacer()
                                
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                                    .opacity(showCards[event.id] == true ? 1 : 0)
                            }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(15)
                            .shadow(color: Color.black.opacity(0.08), radius: 6)
                            .contentShape(Rectangle())
                            .offset(y: showCards[event.id] == true ? 0 : 20)
                            .opacity(showCards[event.id] == true ? 1 : 0)
                            .animation(.easeOut(duration: 0.5).delay(Double(eventData.firstIndex(where: { $0.id == event.id }) ?? 0) * 0.1), value: showCards[event.id])
                        }
                        .buttonStyle(.plain)
                        .onAppear {
                            withAnimation {
                                showCards[event.id] = true
                            }
                        }
                    }
                }
                .padding()
            }
            .background(Color.orange.opacity(0.05))
            .navigationTitle("Event Budaya")
        }
    }
}
