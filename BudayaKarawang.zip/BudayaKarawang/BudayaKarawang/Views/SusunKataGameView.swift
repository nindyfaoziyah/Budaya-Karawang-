//
//  SusunKataGameView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 12/03/26.
//

import SwiftUI


struct SoalGame: Identifiable {
    let id = UUID()
    let jawaban: String
    let petunjuk: String
}

// Data soal
let soalList: [SoalGame] = [
    SoalGame(jawaban: "TARITOPENG", petunjuk: "Tarian khas Karawang"),
    SoalGame(jawaban: "GOYANGKARAWANG", petunjuk: "Musik tradisional Karawang"),
    SoalGame(jawaban: "PEPESIKAN", petunjuk: "Makanan khas Karawang"),
    SoalGame(jawaban: "SEDEKAHBUMI", petunjuk: "Tradisi adat Karawang"),
    SoalGame(jawaban: "CANDIJIWA", petunjuk: "Tempat bersejarah Karawang"),
    SoalGame(jawaban: "SOTOTANGKAR", petunjuk: "Kuliner khas Karawang"),
    SoalGame(jawaban: "SENIGOYANG", petunjuk: "Seni pertunjukan Karawang"),
    SoalGame(jawaban: "TARITOPENGANAK", petunjuk: "Tarian untuk anak-anak"),
    SoalGame(jawaban: "PEPESIKANPEDAS", petunjuk: "Makanan pedas Karawang"),
    SoalGame(jawaban: "PAGELARANBUDAYA", petunjuk: "Event budaya tahunan")
]


struct SusunKataGameView: View {
    
    @State private var soalIndex = 0
    @State private var skor = 0
    @State private var jawabanUser = ""
    @State private var showAlert = false
    @State private var alertText = ""

    var body: some View {
        
        let soal = soalList[soalIndex]
        
        VStack(spacing: 25) {
            
            // HEADER
            VStack(spacing: 8) {
                
                Image(systemName: "puzzlepiece.fill")
                    .font(.system(size: 45))
                    .foregroundColor(.orange)
                
                Text("Susun Kata Budaya")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text("Skor: \(skor)")
                    .font(.headline)
                    .foregroundColor(.orange)
            }
            
            // PROGRESS SOAL
            VStack(alignment: .leading) {
                Text("Soal \(soalIndex + 1) dari \(soalList.count)")
                    .font(.subheadline)
                
                ProgressView(value: Double(soalIndex + 1),
                             total: Double(soalList.count))
                    .tint(.orange)
            }
            
            // PETUNJUK
            VStack {
                Text("Petunjuk")
                    .font(.headline)
                
                Text(soal.petunjuk)
                    .font(.title3)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.center)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.orange.opacity(0.15))
            .cornerRadius(15)
            
            // HURUF ACAK
            VStack(alignment: .leading) {
                
                Text("Susun Huruf Berikut")
                    .font(.headline)
                
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6)) {
                    
                    ForEach(Array(shuffleWord(soal.jawaban)), id: \.self) { huruf in
                        
                        Text(String(huruf))
                            .font(.title2)
                            .fontWeight(.bold)
                            .frame(width: 40, height: 40)
                            .background(Color.orange.opacity(0.2))
                            .cornerRadius(8)
                    }
                }
            }
            
            // INPUT JAWABAN
            TextField("Ketik jawaban di sini...", text: $jawabanUser)
                .padding()
                .background(Color.white)
                .cornerRadius(12)
                .shadow(radius: 2)
                .autocapitalization(.allCharacters)
            
            // TOMBOL CEK
            Button {
                
                if jawabanUser.uppercased() == soal.jawaban {
                    skor += 10
                    alertText = "Benar! 🎉 Skor kamu: \(skor)"
                } else {
                    alertText = "Jawaban masih salah 😅"
                }
                
                showAlert = true
                
            } label: {
                
                Text("Cek Jawaban")
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.orange)
                    .foregroundColor(.white)
                    .cornerRadius(14)
            }
            .shadow(radius: 3)
            
            Spacer()
        }
        .padding()
        .background(Color.orange.opacity(0.05))
        .navigationTitle("Game Susun Kata")
        .alert(alertText, isPresented: $showAlert) {
            
            if jawabanUser.uppercased() == soal.jawaban {
                
                Button("Soal Berikutnya") {
                    
                    jawabanUser = ""
                    
                    if soalIndex + 1 < soalList.count {
                        soalIndex += 1
                    } else {
                        alertText = "Game selesai! Skor akhir kamu: \(skor)"
                    }
                }
                
            } else {
                
                Button("Coba Lagi", role: .cancel) {
                    jawabanUser = ""
                }
            }
        }
    }
    
    // Acak huruf
    func shuffleWord(_ word: String) -> String {
        return String(word.shuffled())
    }
}
