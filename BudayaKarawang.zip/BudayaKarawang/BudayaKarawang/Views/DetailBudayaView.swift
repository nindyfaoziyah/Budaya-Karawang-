//
//  DetailBudayaView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 11/03/26.
//
import SwiftUI

struct DetailBudayaView: View {

    let budaya: Budaya
    @State private var showSections: [String: Bool] = [:] // animasi per section

    var body: some View {
        ScrollView {

            VStack(alignment: .leading, spacing: 20) {

                // FOTO BUDAYA
                Image(budaya.gambar)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 220)
                    .frame(maxWidth: .infinity)
                    .clipped()
                    .cornerRadius(15)
                    .shadow(radius: 5)
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(Color.orange.opacity(0.3), lineWidth: 2)
                    )
                    .padding(.bottom, 10)
                    .transition(.scale.combined(with: .opacity))
                    .animation(.easeOut(duration: 0.5), value: showSections["gambar"])

                // NAMA & ASAL
                VStack(alignment: .leading, spacing: 5) {
                    Text(budaya.nama)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.orange)
                    Text("Asal: \(budaya.asal)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .padding(.horizontal)
                .transition(.move(edge: .leading).combined(with: .opacity))
                .animation(.easeOut(duration: 0.5).delay(0.1), value: showSections["nama"])

                // DESKRIPSI
                SectionCard(title: "Deskripsi", content: budaya.deskripsi)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                    .animation(.easeOut(duration: 0.5).delay(0.2), value: showSections["deskripsi"])

                // SEJARAH
                SectionCard(title: "Sejarah Budaya", content: budaya.sejarah)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                    .animation(.easeOut(duration: 0.5).delay(0.3), value: showSections["sejarah"])

                // LOKASI
                SectionCard(title: "Lokasi Budaya", content: budaya.lokasi, iconName: "mappin.and.ellipse")
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                    .animation(.easeOut(duration: 0.5).delay(0.4), value: showSections["lokasi"])

                // VIDEO
                VStack(alignment: .leading, spacing: 10) {
                    Text("Video Pertunjukan")
                        .font(.headline)

                    Link(destination: URL(string: budaya.videoURL)!) {
                        HStack {
                            Image(systemName: "play.circle.fill")
                            Text("Tonton Video Budaya")
                                .fontWeight(.semibold)
                        }
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.orange)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .shadow(radius: 3)
                    }
                }
                .padding(.horizontal)
                .transition(.opacity)
                .animation(.easeOut(duration: 0.5).delay(0.5), value: showSections["video"])

                // SHARE
                ShareLink(
                    item: "\(budaya.nama) - Budaya dari \(budaya.asal)",
                    subject: Text("Budaya Karawang"),
                    message: Text("Yuk kenali budaya Karawang!")
                ) {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                        Text("Share Budaya")
                            .fontWeight(.semibold)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .shadow(radius: 3)
                }
                .padding(.horizontal)
                .transition(.opacity)
                .animation(.easeOut(duration: 0.5).delay(0.6), value: showSections["share"])

            }
            .padding(.vertical)
        }
        .navigationTitle("Detail Budaya")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            // Trigger animasi saat muncul
            showSections = [
                "gambar": true,
                "nama": true,
                "deskripsi": true,
                "sejarah": true,
                "lokasi": true,
                "video": true,
                "share": true
            ]
        }
    }
}

// MARK: - Komponen Card Section
struct SectionCard: View {
    let title: String
    let content: String
    var iconName: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                if let icon = iconName {
                    Image(systemName: icon)
                        .foregroundColor(.orange)
                }
                Text(title)
                    .font(.headline)
            }
            Text(content)
                .font(.body)
                .foregroundColor(.black)
                .lineSpacing(4)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.08), radius: 6)
        .padding(.horizontal)
    }
}
