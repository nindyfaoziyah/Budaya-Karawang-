//
//  BudayaKarawangApp.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 11/03/26.
//

import SwiftUI

@main
struct BudayaKarawangApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
