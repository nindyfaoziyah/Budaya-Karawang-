//
//  ContentView.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 11/03/26.
//
import SwiftUI

struct ContentView: View {
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView().tabItem {
                Label("Home", systemImage: "house.fill")
            }
            .tag(0)

  
            DaftarBudayaView().tabItem {
                Label("Budaya", systemImage: "list.bullet")
            }
            .tag(1)

           
            EventListView().tabItem {
                Label("Event", systemImage: "calendar")
            }
            .tag(2)

         
            TentangKarawangView().tabItem {
                Label("Tentang", systemImage: "info.circle")
            }
            .tag(3)

          
            GameMenuView().tabItem {
                Label("Game", systemImage: "gamecontroller.fill")
            }
            .tag(4)
        }
        .accentColor(Color.orange)
    }
}

#Preview {
    ContentView()
}
