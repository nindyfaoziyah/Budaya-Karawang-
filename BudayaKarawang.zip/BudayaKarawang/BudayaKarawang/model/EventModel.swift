//
//  EventMode.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 12/03/26.
//

import Foundation

struct EventBudaya: Identifiable {
    let id = UUID()
    let nama: String
    let tanggal: String
    let lokasi: String
    let deskripsi: String
}

let eventData: [EventBudaya] = [

    EventBudaya(
        nama: "Festival Budaya Karawang",
        tanggal: "12 Agustus 2026",
        lokasi: "Alun-Alun Karawang",
        deskripsi: "Festival budaya yang menampilkan tari tradisional, musik daerah, dan kuliner khas Karawang."
    ),

    EventBudaya(
        nama: "Pentas Seni Tradisional",
        tanggal: "5 September 2026",
        lokasi: "Gedung Kesenian Karawang",
        deskripsi: "Acara pertunjukan seni tari dan musik tradisional Karawang."
    ),

    EventBudaya(
        nama: "Pameran Budaya",
        tanggal: "20 Oktober 2026",
        lokasi: "Museum Karawang",
        deskripsi: "Pameran yang menampilkan sejarah dan budaya Karawang."
    )
]
