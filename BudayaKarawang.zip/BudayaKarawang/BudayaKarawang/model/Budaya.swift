//
//  Budaya.swift
//  BudayaKarawang
//
//  Created by Lab Com27 on 11/03/26.
//

import Foundation

struct Budaya: Identifiable {
    let id = UUID()
       let nama: String
       let kategori: String
       let asal: String
       let deskripsi: String
       let sejarah: String
       let lokasi: String
       let gambar: String
       let videoURL: String}

let budayaData: [Budaya] = [

    Budaya(
        nama: "Goyang Karawang",
                kategori: "Musik Tradisional",
                asal: "Karawang, Jawa Barat",
                deskripsi: "Hiburan khas Karawang yang memadukan musik dan tarian.",
                sejarah: "Tari Topeng Karawang berkembang sejak masa kerajaan Sunda dan sering dipentaskan dalam acara adat.",
                lokasi: "Karawang, Jawa Barat",
                gambar: "goyangkarawang",
                videoURL: "https://youtu.be/iMreh26ggbM?si=46Qy81dZ8wjgxavB"
    ),
    Budaya(
        nama: "Tari Topeng",
                kategori: "Seni Tari",
                asal: "Karawang, Jawa Barat",
        deskripsi: "Tari Topeng adalah hiburan khas Karawang yang memadukan musik dan tarian, menggunakan topeng sebagai elemen utama pertunjukan.",
            sejarah: "Tari Topeng Karawang berkembang sejak masa kerajaan Sunda dan sering dipentaskan dalam acara adat sebagai bagian dari tradisi budaya masyarakat setempat.",
                lokasi: "Karawang, Jawa Barat",
                gambar: "topengbanjet",
                videoURL: "https://youtu.be/FZCPTeIYpRQ?si=IHFt7biLFO-mf6ua"
    ),

    Budaya(
        nama: "Pepes Ikan",
                kategori: "Makanan Khas",
                asal: "Karawang, Jawa Barat",
                deskripsi: "Pepes ikan adalah makanan khas yang dibuat dari ikan yang dibumbui rempah-rempah khas Sunda lalu dibungkus daun pisang dan dikukus.",
                sejarah: "Pepes ikan telah menjadi bagian dari kuliner tradisional masyarakat Sunda sejak lama dan sering disajikan dalam acara keluarga maupun kegiatan adat.",
                lokasi: "Karawang, Jawa Barat",
                gambar: "pepespatin",
                videoURL: "https://youtu.be/SQ1NRwEFETk?si=BTr9kLYnxW79EIoz"
    ),

    Budaya(
        nama: "Tradisi Sedekah Bumi",
               kategori: "Tradisi / Adat",
               asal: "Karawang, Jawa Barat",
               deskripsi: "Sedekah Bumi adalah tradisi masyarakat yang dilakukan sebagai ungkapan rasa syukur kepada Tuhan atas hasil panen dan keberkahan alam.",
               sejarah: "Tradisi ini telah dilakukan secara turun-temurun oleh masyarakat Karawang sejak zaman dahulu, biasanya diiringi doa bersama, pertunjukan seni, dan makan bersama.",
                lokasi: "Karawang, Jawa Barat",
                gambar: "sedekahbumi",
                videoURL: "https://youtu.be/ZOw3gD9N7k8?si=Vg95KZ35aE-L8btT"
    ),

    Budaya(
        nama: "Candi Jiwa",
               kategori: "Tempat Bersejarah",
               asal: "Karawang, Jawa Barat",
               deskripsi: "Candi Jiwa merupakan salah satu situs sejarah yang berada di kawasan percandian Batujaya di Karawang.",
               sejarah: "Candi Jiwa diperkirakan berasal dari abad ke-4 hingga ke-7 Masehi dan merupakan peninggalan kerajaan kuno yang menunjukkan adanya pengaruh agama Buddha di wilayah tersebut.",
               lokasi: "Kawasan Percandian Batujaya, Karawang",
                gambar: "candijiwa",
                videoURL: "https://youtu.be/-xjY1eLip50?si=h97_BoxCXHt-580Z"
    )
]
